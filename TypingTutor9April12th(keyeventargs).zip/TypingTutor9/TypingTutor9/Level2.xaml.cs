﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Xaml.Shapes;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace TypingTutor9
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Level2 : Page
    {
        int time;
        char[] keys;
        CommonClass common;
        public Level2()
        {
            this.InitializeComponent();
            CoreWindow.GetForCurrentThread().KeyUp+=Level2_KeyUp;
            common = new CommonClass();
        }      

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.  The Parameter
        /// property is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {         
            keys = new char[8];
            switch (HomeScreen.tappedRow)
            {
                case "1": keys[0] = 'a'; keys[1] = 's'; keys[2] = 'd'; keys[3] = 'f'; keys[4] = 'j'; keys[5] = 'k'; keys[6] = 'l'; keys[7] = ';'; 
                          break;                       
            }
            Random rd = new Random();
            for (int j = 1; j < 10; j++)
            {
                if (j == 5)
                {
                    Button5.IsTabStop = false;
                    Button10.IsTabStop = false;
                    continue;
                }
                int buttonContent = rd.Next(7);
                Button b = (Button)this.FindName("Button" + j.ToString());
                b.Content = keys[buttonContent];
                b.IsTabStop = false;
            }
            Button1.Background = new SolidColorBrush(Colors.Green);
            visibleEllipseOnFinger(common.giveIndication(Button1.Content.ToString()));
           // nextSequence.IsTabStop = false;
        }
        private void Level2_KeyUp(CoreWindow sender, KeyEventArgs args)
        {
            String pressedKey1 = args.VirtualKey.ToString();            
            if (common.specialChars.ContainsKey(pressedKey1))
                pressedKey1 = common.specialChars[pressedKey1];
            DispatcherTimer dt = new DispatcherTimer();
            dt.Interval = new TimeSpan(0, 0, 1);
            dt.Tick += dt_Tick;
            if (forTimerStart == 0)
            {

                dt.Start();
                forTimerStart = 1;
            }
            Button pressedButton = (Button)this.FindName("Button" + buttons.ToString());
            if (buttons == 11)
            {
                buttons = 1;
                nextSequence_Click_1(this, new RoutedEventArgs());
                return;
            }
            string pressedLetter = pressedButton.Content.ToString();
            if (pressedLetter.Equals(pressedKey1.ToLower()) || pressedLetter.Equals(pressedKey1))
            {
                buttons++;
                collapseEllipseOnFinger(common.giveIndication(pressedLetter));
                Button nextLetter = (Button)this.FindName("Button" + buttons.ToString());
                pressedButton.Foreground = new SolidColorBrush(Colors.Blue);
                if (buttons < 10)
                {
                    nextLetter.Background = new SolidColorBrush(Colors.Green);
                    visibleEllipseOnFinger(common.giveIndication(nextLetter.Content.ToString()));
                }
                else
                {
                    pressedButton.Background = new SolidColorBrush(Colors.Green);
                }

            }
            else
            {
                pressedKey1 = args.VirtualKey.ToString();
                if ("Shift".Contains(pressedKey1))
                {
                    if (args.KeyStatus.ScanCode == 42)
                        pressedKey1 = "LeftShift";
                    else if (args.KeyStatus.ScanCode == 54)
                        pressedKey1 = "RightShift";
                }
                if (common.specialChars.ContainsKey(pressedKey1))
                    pressedKey1 = "_" + pressedKey1;

                Rectangle wrongKey = (Rectangle)this.FindName(pressedKey1);
                wrongKey.Visibility = Visibility.Visible;
            }
        }
        int forTimerStart,buttons = 1;
        public void showWrongMarkOnKey(string pressedKey1)
        {
            throw new NotImplementedException();
        }

        private void dt_Tick(object sender, object e)
        {
            time++;
            clk.Text = time.ToString();
            //throw new NotImplementedException();
        }

        private void bn_Click_1(object sender, RoutedEventArgs e)
        {

        }
        int numberOfSequences;
        private void nextSequence_Click_1(object sender, RoutedEventArgs e)
        {
            if (numberOfSequences > 30)
            {
                this.Frame.Navigate(typeof(HomeScreen), HomeScreen.userId1);
            }
            else
            {
                Random rd = new Random();
                for (int j = 1; j < 10; j++)
                {

                    int buttonContent = rd.Next(8);
                    Button b = (Button)this.FindName("Button" + j.ToString());
                    if(j!=5)
                        b.Content = keys[buttonContent];
                    b.Background = new SolidColorBrush(Colors.SkyBlue);
                    b.Foreground = new SolidColorBrush(Colors.White);
                }
                Button1.Background = new SolidColorBrush(Colors.Green);
                Button10.Background = new SolidColorBrush(Colors.SkyBlue);
                Button10.Foreground = new SolidColorBrush(Colors.White);
                visibleEllipseOnFinger(common.giveIndication(Button1.Content.ToString()));
            }
        }
        public void visibleEllipseOnFinger(string ellipseID)
        {
            try
            {
                if (ellipseID != null)
                {
                    Ellipse finger = (Ellipse)this.FindName(ellipseID);
                    finger.Visibility = Visibility.Visible;
                }
            }
            catch (Exception ee)
            {
                
            }
        }
        public void collapseEllipseOnFinger(string ellipseID)
        {
            try
            {
                if (ellipseID != null)
                {
                    Ellipse finger = (Ellipse)this.FindName(ellipseID);
                    if(finger.Visibility==Visibility.Visible)
                        finger.Visibility = Visibility.Collapsed;
                }
            }
            catch (Exception ee)
            {

            }
        }
    }
}
