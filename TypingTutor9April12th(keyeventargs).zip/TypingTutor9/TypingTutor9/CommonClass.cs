﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Shapes;

namespace TypingTutor9
{
    class CommonClass
    {
        public  Dictionary<string,string> lettersNFingers = new Dictionary<string,string>();
        public Dictionary<string, string> specialChars = new Dictionary<string, string>();
        public string[] doubleKeys = new string[8];
        public CommonClass()
        {
            lettersNFingers.Add("a", "LeftLittle");
            lettersNFingers.Add("s", "LeftRing");
            lettersNFingers.Add("d", "LeftMiddle");
            lettersNFingers.Add("f", "Left1");
            lettersNFingers.Add("j", "Right1");
            lettersNFingers.Add("k", "RightMiddle");
            lettersNFingers.Add("l", "RightRing");
            lettersNFingers.Add(";", "RightLittle");
            specialChars.Add("186", ";");
            specialChars.Add("188", ",");
            specialChars.Add("190", ".");
            specialChars.Add("222", "'");
            specialChars.Add("191", "/");
            specialChars.Add("220", "\\");
            specialChars.Add("219", "[");
            specialChars.Add("221", "]");
            specialChars.Add("187", "=");
            specialChars.Add("189", "-");
            specialChars.Add("Number1", "1");
            specialChars.Add("Number2", "2");
            specialChars.Add("Number3", "3");
            specialChars.Add("Number4", "4");
            specialChars.Add("Number5", "5");
            specialChars.Add("Number6", "6");
            specialChars.Add("Number7", "7");
            specialChars.Add("Number8", "8");
            specialChars.Add("Number9", "9");
            specialChars.Add("Number0", "0");
            specialChars.Add("192", "`");
            specialChars.Add("173", "mute");
            specialChars.Add("174", "lowVolume");
            specialChars.Add("175", "increaseVolume");
            specialChars.Add("255", "e");
                      
        }
        public string giveIndication(string key)
        {
            if (lettersNFingers.ContainsKey(key))
            {
                return lettersNFingers[key];
            }
            return null;
        }

        internal string leftOrRight(string pressedKey1)
        {
            switch (pressedKey1)
            {
                case "Shift":
                                break;
            }
            return null;
        }
    }
}
