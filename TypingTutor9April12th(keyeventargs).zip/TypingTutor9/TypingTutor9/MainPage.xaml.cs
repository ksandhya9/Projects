﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using SQLite;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace TypingTutor9
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.  The Parameter
        /// property is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            Login_Click_1(this, new RoutedEventArgs());
        }

        private async void Login_Click_1(object sender, RoutedEventArgs e)
        {
            var userId = "ksandhya";// UserName.Text;
            if (userId != "")
            {
                SQLiteAsyncConnection conn = new SQLiteAsyncConnection("LearnersDb.db");
                var result = await conn.QueryAsync<Users>("Select userName FROM Users where userName='"+userId+"'");
                foreach (var item in result)
                {
                    this.Frame.Navigate(typeof(HomeScreen), userId);
                    return;                    
                }
                newUserGrid.Visibility = Visibility.Visible;
                newUserName.Text = "register please";
            }
        }

        private void NewUser_Click_1(object sender, RoutedEventArgs e)
        {
            newUserGrid.Visibility = Visibility.Visible;
        }

        private async void Register_Click_1(object sender, RoutedEventArgs e)
        {
            SQLiteAsyncConnection conn = new SQLiteAsyncConnection("LearnersDB.db");
            await conn.CreateTableAsync<Users>();
            if (newUserName.Text!= " ")
            {
                var newuser = new Users()
                {
                    userName = newUserName.Text,
                    homeRow="-1",
                    topRow="-1",
                    bottomRow="-1",
                    numberKeys="-1",
                    specialKeys="-1"
                };
                await conn.InsertAsync(newuser);
            }
        }
    }
}
