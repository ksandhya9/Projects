﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using SQLite;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace TypingTutor9
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class HomeScreen : Page
    {
       public static string tappedRow;
        public static string userId1;
        public HomeScreen()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.  The Parameter
        /// property is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            userId1 = e.Parameter as string;
            homeRow_Tapped_1(this, new TappedRoutedEventArgs());//delete this 2 line it is for testing            
        }

        private void homeRow_Tapped_1(object sender, TappedRoutedEventArgs e)
        {
            homePage.Visibility = Visibility.Collapsed;
            Levels.Visibility = Visibility.Visible;
            //int i = 1;
            //Button b = (Button)this.FindName("Level" + i.ToString());
            //b.Content = "content changed";
            tappedRow = "1";
        }

        private void Level1_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Level2_Click_1(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(Level2));
        }

        private void Level3_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Level4_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Level5_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Level6_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Level7_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void TopRow_Tapped_1(object sender, TappedRoutedEventArgs e)
        {

        }

        private void BottomRow_Tapped_1(object sender, TappedRoutedEventArgs e)
        {

        }

        private void NumbersRow_Tapped_1(object sender, TappedRoutedEventArgs e)
        {

        }

        private void StackPanel_Tapped_1(object sender, TappedRoutedEventArgs e)
        {

        }

        private void SpecialKeys_Tapped_1(object sender, TappedRoutedEventArgs e)
        {

        }

        private void About_Tapped_1(object sender, TappedRoutedEventArgs e)
        {

        }

        private void Result_Tapped_1(object sender, TappedRoutedEventArgs e)
        {

        }

        private void Settings_Tapped_1(object sender, TappedRoutedEventArgs e)
        {


        }
    }
}
